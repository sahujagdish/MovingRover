import { TabWrapperModule } from './tab-wrapper.module';

describe('TabWrapperModule', () => {
  let tabWrapperModule: TabWrapperModule;

  beforeEach(() => {
    tabWrapperModule = new TabWrapperModule();
  });

  it('should create an instance', () => {
    expect(tabWrapperModule).toBeTruthy();
  });
});
