import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-tab-wrapper',
  templateUrl: './tab-wrapper.component.html',
  styleUrls: ['./tab-wrapper.component.scss'],
})
export class TabWrapperComponent implements OnInit {

  @Input("tabId") tabId: string;

  constructor() { }

  ngOnInit() { }

}
