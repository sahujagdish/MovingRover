import { Component, OnInit, ViewChild } from '@angular/core';
import { User } from '../user/user';

@Component({
  selector: 'app-second-page',
  templateUrl: './second-page.component.html',
  styleUrls: ['./second-page.component.css']
})
export class SecondPageComponent implements OnInit {
  user: User;

  constructor() { }

  ngOnInit() {
    this.user = new User();
  }

}