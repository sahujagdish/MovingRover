import { Component, OnInit, HostListener, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user/user';
import { HomepageComponent } from '../homepage/homepage.component';

@Component({
  selector: 'app-first-page',
  templateUrl: './first-page.component.html',
  styleUrls: ['./first-page.component.css']
})
export class FirstPageComponent implements OnInit {
  user: User;

  constructor(private homePagereferance: HomepageComponent) { }

  ngOnInit() {
    this.user = new User();
   }

  registerMe() {
    this.homePagereferance.openTab('second page', 'secondpage', undefined);
  }

}
