import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {
  activeLinkIndex = -1;
  navLinks: any[];
  link: any;
  counter: number = 0;

  constructor() { }

  ngOnInit() {
    this.navLinks = [];
  }

  openLogin() {
    let tabTitle = "First Page";
    let tabId = "firstpage";
    let param = undefined;
    this.openTab(tabTitle, tabId, undefined);
  }

  openReg() {
    let tabTitle = "Second Page";
    let tabId = "secondpage";
    let param = undefined;
    this.openTab(tabTitle, tabId, undefined);
  }

  duplicate() {
    this.counter++;
    let tabTitle = "duplicate " + this.counter;
    let tabId = "firstpage";
    let param = undefined;
    this.openTab(tabTitle, tabId, "allow duplicate");
  }


  public openTab(heading: String, route: String, parameter: any) {
    console.log("openTab in layout... IN");
    var res;
    var navFlag = false;
    var tabLength = this.navLinks.length;
    if (parameter == "allow duplicate") {
      navFlag = false;
    } else {
      debugger;
      for (var i = 0; i < this.navLinks.length; i++) {
        if (this.navLinks[i].link == route) {
          navFlag = true;
          if (!this.navLinks[i].parameter) {
            this.activeLinkIndex = i;
          } else {
            this.activeLinkIndex = i;
          }
          break;
        } else {
          navFlag = false;
        }
      }
    }

    if (navFlag == false) {
      this.navLinks.push({
        label: heading,
        link: route,
        index: tabLength,
        parameter: parameter
      });

      if (parameter == "allow duplicate") {
        this.activeLinkIndex = this.navLinks.length;
      } else {
        this.activeLinkIndex = tabLength;
      }
    }
    console.log("openTab in layout... OUT");
  }

  closeTab(index: number) {
    console.log("closeTab in layout component... IN");
    var maxTabIndex;
    var res;
    if (this.activeLinkIndex == index) {
      maxTabIndex = this.navLinks.length - 1;
      if (maxTabIndex == 0) {
        this.navLinks.splice(index, 1);
      } else if (index < maxTabIndex) {
        this.navLinks.splice(index, 1);

        this.activeLinkIndex = index;
      } else if (index == maxTabIndex) {
        this.navLinks.splice(index, 1);
        maxTabIndex = this.navLinks.length - 1;

        this.activeLinkIndex = maxTabIndex;
      } else {
      }
    } else if (this.activeLinkIndex > index) {
      this.navLinks.splice(index, 1);
      this.activeLinkIndex = this.activeLinkIndex - 1;
    } else {
      this.navLinks.splice(index, 1);
    }
    if (this.navLinks.length <= 0) {
    }
    console.log("closeTab in layout component... OUT");
  }

  closeOtherTabs(index: number) {
    console.log("closeOtherTabs in layout component... IN");
    this.link = this.navLinks[index];
    this.navLinks = [];
    this.navLinks.push(this.link);

    this.activeLinkIndex = 0;
    this.link = undefined;
    console.log("closeOtherTabs in layout component... OUT");
  }

  closeAllTabs() {
    console.log("closeAllTabs in layout component... IN");
    this.activeLinkIndex = -1;
    this.navLinks = [];
    console.log("closeAllTabs in layout component... OUT");
  }

  activate(index: number) {
    console.log("activate in layout component... IN");
    if (!this.navLinks[index].parameter) {
      this.activeLinkIndex = index;
    } else {
      this.activeLinkIndex = index;
    }
    console.log("activate in layout component... OUT");
  }

}