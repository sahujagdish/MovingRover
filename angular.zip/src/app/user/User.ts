export class User {
    id: Number;
    userName: String;
    password: String;
    email: String;
    contactNo: String;
    address: String;
    edited: Boolean;

    constructor() { };
}